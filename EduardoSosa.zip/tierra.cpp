#include "tierra.h"

//CONSTRUCTOR
Tierra::Tierra(string nombre, int escudo, int vida) : Personaje(nombre, escudo, vida){}

int Tierra::recuperadoTierra(int energia)
{
    if(energia + RECUPERATIERRA > ENERGIAMAX)
    {
        return RECUPERATIERRA - ((energia + RECUPERATIERRA) - ENERGIAMAX);
    }
    else
    {
        return RECUPERATIERRA;
    }
}


//FUNCIONES Y METODOS PRINCIPALES
void Tierra::alimentar()
{
    int recuperado = 0;
    recuperado = recuperadoTierra(energia);
    energia += recuperado;
    cout << "\nAlimentado con " << ALIMENTOTIERRA << endl;
    cout << "Recupera " << recuperado << " puntos de energía" << endl;

}

void Tierra::mostrarInformacion()
{
    Personaje::mostrarInformacion();
    cout << "Elemento: " << TIERRA << endl;
}

Tierra::~Tierra(){}