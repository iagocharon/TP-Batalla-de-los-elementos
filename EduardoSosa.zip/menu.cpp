#include "menu.h"

Menu::Menu(){}

void Menu::mostrarMenu()
{
    cout << "\n1 - Agregar nuevo personaje" << endl;
    cout << "2 - Eliminar un personaje" << endl;
    cout << "3 - Mostrar todos los nombres de los personajes" << endl;
    cout << "4 - Buscar por nombre los detalles de un personaje en particular" << endl;
    cout << "5 - Alimentar un personaje" << endl;
    cout << "6 - Salir" << endl;
}

void Menu::ejecutarInstruccion(int instruccion, Lista &lista)
{
    AccionesMenu* accion;
    switch(instruccion)
    {
        case 1:
            accion->agregarPersonaje(lista);
            break;
        case 2:
            accion->eliminarPersonaje(lista);
            break;
        case 3:
            accion->listarNombres(lista);
            break;
        case 4:
            accion->buscarDetalles(lista);
            break;
        case 5:
            accion->alimentarPersonaje(lista);
            break;
        case 6:
            break;
        default:
            cout << "Instruccion inválida." << endl;
            break;
    }
}