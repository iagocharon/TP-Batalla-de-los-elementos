#ifndef TP2_ACCIONESMENU_H
#define TP2_ACCIONESMENU_H

#include <iostream>
#include "lista.h"

const int ALFINAL = 1;
const int ENPOSICION = 2;
const int PORNOMBRE = 3;
const int LISTARNOMBRES = 4;
const int CANTIDADELEMENTOS = 4;

using namespace std;

class AccionesMenu
{
public:

    //PRE:
    //POS:
    AccionesMenu();

    //PRE:
    //POS: Agrega un Nodo* con el dato personaje cargado a la lista.
    void agregarPersonaje(Lista &lista);

    //PRE:
    //POS: Elimina un Nodo* de la lista.
    void eliminarPersonaje(Lista &lista);

    //PRE:
    //POS: Alimenta a un personaje llamando al procedimiento correspondiente según el elemento.
    void alimentarPersonaje(Lista &lista);

    // PRE:
    // POS: muestra por pantalla todos los nombres de los personajes en la lista y su posicion.
    void listarNombres(Lista &lista);

    //PRE:
    //POS: Muestra por pantalla la información del personaje solicitado.
    void buscarDetalles(Lista &lista);

    //PRE:
    //POS:
    virtual ~AccionesMenu() = 0;

private:
    //AGREGAR NUEVO PERSONAJE

    //PRE:
    //POS: Muestra por pantalla las opciones de elemento al crear personaje.
    void opcionesElemento();

    //PRE:
    //POS: Muestra por pantalla las opciones de donde se puede insertar el presonaje creado.
    void opcionesAgregar();

    //PRE:
    //POS: Devuelve un int que representa la opcion seleccionada sobre donde insertar al personaje.
    int seleccionarOpcionAgregar();

    //PRE:
    //POS: Devuelve un string con el elemento seleccionado del nuevo personaje.
    string seleccionElemento();

    //PRE:
    //POS: Inicializa las estadisticas de un personaje de forma aleatoria.
    void estadisticasAleatorias(int &escudo, int &vida);

    //PRE:
    //POS: Devuelve un Nodo* con el dato personaje cargado.
    Nodo* crearPersonaje();


    //ELIMINAR PERSONAJE

    //PRE:
    //POS: Muestra por pantalla las opciones de donde se puede eliminar a un personaje.
    void opcionesEliminar();

    //PRE:
    //POS: Devuelve un int que representa la opcion seleccionada sobre donde eliminar el personaje.
    int seleccionarOpcionEliminar();

    //PRE:
    //POS: Devuelve la posicion de un personaje dado un nombre
    // (en caso de que haya vario devuelve el primero)(si no encuentra al personaje devuelve -1).
    int buscarPosicion(string nombre, Lista &lista);

    //PRE:
    //POS: Muestra la información de un personaje según un nombre dado.
    void consultarInformacion(string nombre, Lista &lista);

    //PRE:
    //POS: Devuelve un puntero a un personaje según un nombre dado.
    Personaje* consultarPersonaje(string nombre, Lista &lista);
};

#endif //TP2_ACCIONESMENU_H
