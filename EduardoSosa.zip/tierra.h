#ifndef TP2_TIERRA_H
#define TP2_TIERRA_H

#include "personaje.h"

using namespace std;

const string TIERRA = "tierra";
const string ALIMENTOTIERRA = "hierbas";
const int RECUPERATIERRA = 8;

class Tierra : public Personaje
{
public:
    // PRE:
    // POS: crea un personaje de tierra con nombre = nombre, escudo = escudo,
    //      vida = vida, energía aleatoria entre ENERGIAMIN y ENERGIAMAX.
    Tierra(string nombre, int escudo, int vida);

    // PRE:
    // POS: muestra toda la informacion del personaje.
    void mostrarInformacion();

    // PRE:
    // POS: alimenta al personaje y muestra el efecto provocado.
    void alimentar();

    // PRE:
    // POS: elimina al personaje liberando la memoria.
    virtual ~Tierra();

private:
    //PRE:
    //POS: Devuelve la cantidad de energía que recupera el personaje.
    int recuperadoTierra(int energia);
};

#endif //TP2_TIERRA_H
