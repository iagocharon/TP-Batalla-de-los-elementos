#include "personaje.h"

//CONSTRUCTOR
Personaje::Personaje(string nombre, int escudo, int vida)
{
    this->nombre = nombre;
    this->escudo = escudo;
    this->vida = vida;
    energia = rand() % (ENERGIAMAX+1);
}

string Personaje::obtenerNombre()
{
    return nombre;
}

void Personaje::mostrarInformacion()
{
    cout << "\nNombre: " << nombre << endl;
    cout << "Vida: " << vida << endl;
    cout << "Escudo: " << escudo << endl;
    cout << "Energía: " << energia << endl;
}

Personaje::~Personaje(){}