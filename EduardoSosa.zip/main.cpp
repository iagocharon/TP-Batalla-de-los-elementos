#include <iostream>
#include <ctime>
#include <cstdlib>
#include "lista.h"
#include "menu.h"
#include "archivo.h"

using namespace std;

int main() {
    srand(time(0));

    Archivo* archivo;
    Menu* menu;
    int instruccion = 0;
    Lista lista = archivo->cargarPersonajes();
    do
    {
        menu->mostrarMenu();
        cin >> instruccion;
        menu->ejecutarInstruccion(instruccion, lista);
    }while(instruccion != SALIR);


    return 0;
}
