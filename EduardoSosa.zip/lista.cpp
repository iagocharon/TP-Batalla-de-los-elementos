#include "lista.h"

//CONSTRUCTOR
Lista::Lista()
{
    cantidadElementos = 0;
    primero = nullptr;
    ultimo = nullptr;
}

//FUNCIONES Y METODOS AUXILIARES

//FUNCIONES Y METODOS PRINCIPALES

void Lista::alta(Nodo* elemento)
{
    if(cantidadElementos == 0)
    {
        primero = elemento;
        ultimo = elemento;
    }
    else
    {
        ultimo->cambiarSiguiente(elemento);
        ultimo = elemento;
    }
    cantidadElementos++;
}

void Lista::alta(int posicion, Nodo* elemento)
{
    Nodo* auxiliar = nullptr;

    if(cantidadElementos > 0)
    {
        if(posicion == 0)
        {
            auxiliar = elemento;
            auxiliar->cambiarSiguiente(primero);
            primero = auxiliar;
            cantidadElementos++;
        }
        else if(posicion > 0 && posicion < cantidadElementos)
        {
            auxiliar = primero;
            for(int i = 0; i < posicion-1; i++)
            {
                auxiliar = auxiliar->obtenerSiguiente();
            }
            elemento->cambiarSiguiente(auxiliar->obtenerSiguiente());
            auxiliar->cambiarSiguiente(elemento);
            cantidadElementos++;
        }
        else
        {
            alta(elemento);
        }
    }
    else
    {
        alta(elemento);
    }
}

void Lista::baja()
{
    Nodo* auxiliar = primero;

    if(cantidadElementos == 1)
    {
        delete ultimo;
        ultimo = nullptr;
        primero = nullptr;
    }
    else if(cantidadElementos == 2)
    {
        delete ultimo;
        ultimo = primero;
        primero->cambiarSiguiente(nullptr);
    }
    else if(cantidadElementos > 2)
    {
        for(int i = 0; i < cantidadElementos-2; i++)
        {
            auxiliar = auxiliar->obtenerSiguiente();
        }
        delete ultimo;
        ultimo = auxiliar;
        ultimo->cambiarSiguiente(nullptr);
    }
    else
    {
        return;
    }

    cantidadElementos--;
}

void Lista::baja(int posicion)
{
    Nodo* auxiliar1 = primero;
    Nodo* auxiliar2 = primero;

    if(cantidadElementos > 1)
    {
        if(posicion >= cantidadElementos-1 || posicion < 0)
        {
            baja();
        }
        else if(posicion == 0)
        {
            auxiliar1 = auxiliar1->obtenerSiguiente();
            delete primero;
            primero = auxiliar1;
        }
        else
        {
            auxiliar1 = auxiliar1->obtenerSiguiente();
            for(int i = 0; i < posicion-1; i++)
            {
                auxiliar1 = auxiliar1->obtenerSiguiente();
                auxiliar2 = auxiliar2->obtenerSiguiente();
            }
            auxiliar2->cambiarSiguiente(auxiliar1->obtenerSiguiente());
            delete auxiliar1;
        }

        cantidadElementos--;
    }
    else
    {
        baja();
    }
}

Nodo* Lista::consultarPrimero()
{
    return primero;
}


Lista::~Lista()
{
    Nodo* auxiliar = primero;
    while(auxiliar){
        auxiliar = primero->obtenerSiguiente();
        delete primero;
        primero = auxiliar;
    }
}
