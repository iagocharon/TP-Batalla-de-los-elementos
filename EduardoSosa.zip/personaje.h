#ifndef TP2_PERSONAJE_H
#define TP2_PERSONAJE_H

#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

const int VIDAMAX = 100;
const int VIDAMIN = 10;
const int ENERGIAMAX = 20;
const int ESCUDOMAX = 2;

class Personaje
{
protected:
    string nombre;
    int escudo;
    int vida;
    int energia;

public:
    // PRE:
    // POS: crea un personaje con nombre = nombre, escudo = escudo,
    //      vida = vida, energía aleatoria entre ENERGIAMIN y ENERGIAMAX.
    Personaje(string nombre, int escudo, int vida);

    // PRE:
    // POS: devuelve el nombre del personaje.
    string obtenerNombre();

    // PRE:
    // POS: muestra toda la informacion del personaje.
    virtual void mostrarInformacion();

    // PRE:
    // POS:
    virtual void alimentar() = 0;

    // PRE:
    // POS: elimina al personaje liberando la memoria.
    virtual ~Personaje();
};

#endif //TP2_PERSONAJE_H
