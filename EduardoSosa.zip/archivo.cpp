#include "archivo.h"

Archivo::Archivo() {}


Lista Archivo::cargarPersonajes()
{
    string elemento = "";
    string nombre = "";
    string escudo = "";
    string vida = "";
    Personaje* personaje = nullptr;
    Nodo* nodo = nullptr;
    Lista lista = Lista();

    ifstream archivo(ARCHIVO, ios::in);

    if(!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo." << endl;
        return lista;
    }

    while(getline(archivo, elemento, ','))
    {
        getline(archivo, nombre, ',');
        getline(archivo, escudo, ',');
        getline(archivo, vida, '\n');


        if(elemento == AIRE)
        {
            personaje = new Aire(nombre, stoi(escudo), stoi(vida));
        }
        else if(elemento == AGUA)
        {
            personaje = new Agua(nombre, stoi(escudo), stoi(vida));
        }
        else if(elemento == TIERRA)
        {
            personaje = new Tierra(nombre, stoi(escudo), stoi(vida));
        }
        else
        {
            personaje = new Fuego(nombre, stoi(escudo), stoi(vida));
        }

        nodo = new Nodo();
        nodo->cambiarDato(personaje);
        lista.alta(nodo);
    }

    archivo.close();
    return lista;
}