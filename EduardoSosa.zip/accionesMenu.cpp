#include "accionesMenu.h"

AccionesMenu::AccionesMenu(){}

//-------------------AGREGAR PERSONAJE----------------------

void AccionesMenu::opcionesElemento()
{
    cout << "\n1 - Aire" << endl;
    cout << "2 - Agua" << endl;
    cout << "3 - Tierra" << endl;
    cout << "4 - Fuego" << endl;
}

void AccionesMenu::opcionesAgregar()
{
    cout << "\n1 - Agregar al final" << endl;
    cout << "2 - Agregar en posicion predefinida" << endl;
    cout << "4 - Listar nombres y posiciones" << endl;
}

int AccionesMenu::seleccionarOpcionAgregar()
{
    int instruccion = 0;
    do
    {
        opcionesAgregar();
        cin >> instruccion;
        getchar();
        if(instruccion != ALFINAL && instruccion != ENPOSICION && instruccion != LISTARNOMBRES)
        {
            cout << "Ingreso inválido" << endl;
        }
    }while(instruccion != ALFINAL && instruccion != ENPOSICION && instruccion != LISTARNOMBRES);

    return instruccion;
}

string AccionesMenu::seleccionElemento()
{
    int instruccion = 0;
    string elemento = "";
    do
    {
        opcionesElemento();
        cin >> instruccion;
        if(instruccion <= 0 || instruccion > CANTIDADELEMENTOS)
        {
            cout << "Ingreso inválido" << endl;
        }
    }while(instruccion <= 0 || instruccion > CANTIDADELEMENTOS);

    switch(instruccion)
    {
        case 1:
            elemento = AIRE;
            break;
        case 2:
            elemento = AGUA;
            break;
        case 3:
            elemento = TIERRA;
            break;
        case 4:
            elemento = FUEGO;
            break;
        default:
            break;
    }
    return elemento;
}

void AccionesMenu::estadisticasAleatorias(int &escudo, int &vida)
{
    escudo = rand() % (ESCUDOMAX+1);
    vida = (rand() % (VIDAMAX-9)) + VIDAMIN;
}

Nodo* AccionesMenu::crearPersonaje()
{
    int escudo = 0;
    int vida = 0;
    string elemento = "";
    string nombre = "";
    Personaje* nuevoPersonaje;
    Nodo* nodo  = new Nodo();

    elemento = seleccionElemento();
    estadisticasAleatorias(escudo, vida);

    cout << "\nIngrese el nombre del personaje: ";
    cin >> nombre;

    if(elemento == AIRE)
    {
        nuevoPersonaje = new Aire(nombre, escudo, vida);
    }
    else if(elemento == AGUA)
    {
        nuevoPersonaje = new Agua(nombre, escudo, vida);
    }
    else if(elemento == TIERRA)
    {
        nuevoPersonaje = new Tierra(nombre, escudo, vida);
    }
    else
    {
        nuevoPersonaje = new Fuego(nombre, escudo, vida);
    }

    nodo->cambiarDato(nuevoPersonaje);

    return nodo;
}

void AccionesMenu::agregarPersonaje(Lista &lista)
{
    int agregar = 0;
    int posicion = 0;
    Nodo* nodo;

    do
    {
        agregar = seleccionarOpcionAgregar();
        if(agregar == LISTARNOMBRES)
        {
            listarNombres(lista);
        }
    }while(agregar == LISTARNOMBRES);
    nodo = crearPersonaje();

    if(agregar == ENPOSICION)
    {
        cout << "\nIngrese la posicion en la que ingresara el personaje" << endl;
        cin >> posicion;
        lista.alta(posicion, nodo);
    }
    else
    {
        lista.alta(nodo);
    }
}


//-------------------ELIMINAR PERSONAJE----------------------

void AccionesMenu::opcionesEliminar()
{
    cout << "\n1 - Eliminar al ultimo" << endl;
    cout << "2 - Eliminar en posicion predefinida" << endl;
    cout << "3 - Eliminar por nombre" << endl;
    cout << "4 - Listar nombres y posiciones" << endl;
}

int AccionesMenu::seleccionarOpcionEliminar()
{
    int instruccion = 0;
    do
    {
        opcionesEliminar();
        cin >> instruccion;
        if(instruccion != ALFINAL && instruccion != ENPOSICION && instruccion != PORNOMBRE &&
        instruccion != LISTARNOMBRES)
        {
            cout << "Ingreso inválido" << endl;
        }
    }while(instruccion != ALFINAL && instruccion != ENPOSICION && instruccion != PORNOMBRE &&
    instruccion != LISTARNOMBRES);

    return instruccion;
}

int AccionesMenu::buscarPosicion(string nombre, Lista &lista)
{
    Nodo* auxiliar = lista.consultarPrimero();
    int contador = 0;

    while(auxiliar)
    {
        if(auxiliar->obtenerDato()->obtenerNombre() == nombre)
        {
            return contador;
        }

        auxiliar = auxiliar->obtenerSiguiente();
        contador++;
    }

    return -1;
}

void AccionesMenu::eliminarPersonaje(Lista &lista)
{
    int instruccion = 0;
    int posicion = 0;
    string nombre = "";

    do {
        instruccion = seleccionarOpcionEliminar();
        if(instruccion == LISTARNOMBRES)
        {
            listarNombres(lista);
        }
    }while(instruccion == LISTARNOMBRES);

    if(instruccion == ENPOSICION)
    {
        cout << "\nIngrese la posición del personaje a eliminar:" << endl;
        cin >> posicion;
        lista.baja(posicion);
    }
    else if(instruccion == PORNOMBRE)
    {
        cout << "\nIngrese el nombre del personaje a eliminar:" << endl;
        cin >> nombre;
        posicion = buscarPosicion(nombre, lista);
        if(posicion == -1)
        {
            cout << "\nPersonaje no encontrado :(" << endl;
            return;
        }
        lista.baja(posicion);
    }
    else
    {
        lista.baja();
    }

}
//-----------------------------------------------------------


Personaje* AccionesMenu::consultarPersonaje(string nombre, Lista &lista)
{
    Nodo* auxiliar = lista.consultarPrimero();

    while(auxiliar)
    {
        if(nombre == auxiliar->obtenerDato()->obtenerNombre())
        {
            return auxiliar->obtenerDato();
        }

        auxiliar = auxiliar->obtenerSiguiente();
    }

    return nullptr;
}

void AccionesMenu::alimentarPersonaje(Lista &lista)
{
    string nombre = "";
    Personaje* personaje;

    listarNombres(lista);
    cout << "\n Ingrese el nombre del personaje a alimentar" << endl;
    cin >> nombre;

    personaje = consultarPersonaje(nombre, lista);

    if(!personaje)
    {
        cout << "\n Personaje no encontrado :(" << endl;
    }
    else
    {
        personaje->alimentar();
    }
}


void AccionesMenu::listarNombres(Lista &lista)
{
    Nodo* auxiliar = lista.consultarPrimero();
    cout << "\n" << endl;
    for(int i = 0; auxiliar; i++)
    {
        cout << i << " - " << auxiliar->obtenerDato()->obtenerNombre() << endl;
        auxiliar = auxiliar->obtenerSiguiente();
    }
}


void AccionesMenu::consultarInformacion(string nombre, Lista &lista)
{
    Nodo* auxiliar = lista.consultarPrimero();

    if(!auxiliar)
    {
        return;
    }

    cout << "\n" << endl;

    while(auxiliar)
    {
        if(nombre == auxiliar->obtenerDato()->obtenerNombre())
        {
            auxiliar->obtenerDato()->mostrarInformacion();
            return;
        }
        auxiliar = auxiliar->obtenerSiguiente();
    }

    cout << "Personaje no encontrado :(" << endl;
}


void AccionesMenu::buscarDetalles(Lista &lista)
{
    string nombre = "";
    cout << "\nIngrese el nombre: ";
    cin >> nombre;
    cout << endl;
    consultarInformacion(nombre, lista);
}