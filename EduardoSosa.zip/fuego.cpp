#include "fuego.h"

//CONSTRUCTOR
Fuego::Fuego(string nombre, int escudo, int vida) : Personaje(nombre, escudo, vida){}


//FUNCIONES Y METODOS AUXILIARES

//PRE:
//POS: Devuelve la cantidad de vida que recupera el personaje.
int Fuego::recuperadoFuego(int vida)
{
    if(vida + RECUPERAFUEGO > VIDAMAX)
    {
        return RECUPERAFUEGO - ((vida + RECUPERAFUEGO) - VIDAMAX);
    }
    else
    {
        return RECUPERAFUEGO;
    }
}


//FUNCIONES Y METODOS PRINCIPALES
void Fuego::alimentar()
{
    int recuperado = 0;
    recuperado = recuperadoFuego(vida);
    cout << "\nAlimentado con " << ALIMENTOFUEGO << endl;
    cout << "Recupera " << recuperado << " puntos de vida" << endl;
}

void Fuego::mostrarInformacion()
{
    Personaje::mostrarInformacion();
    cout << "Elemento: " << FUEGO << endl;
}

Fuego::~Fuego(){}