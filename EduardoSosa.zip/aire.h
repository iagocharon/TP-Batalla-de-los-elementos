#ifndef TP2_AIRE_H
#define TP2_AIRE_H

#include "personaje.h"

const string AIRE = "aire";

using namespace std;

class Aire : public Personaje
{
public:
    // PRE:
    // POS: crea un personaje de agua con nombre = nombre, escudo = escudo,
    //      vida = vida, energía aleatoria entre ENERGIAMIN y ENERGIAMAX y vecesAlimentado = 0.
    Aire(string nombre, int escudo, int vida);

    // PRE:
    // POS: muestra toda la informacion del personaje.
    void mostrarInformacion();

    // PRE:
    // POS: muestra un mensaje (los personajes de aire no se alimentan).
    void alimentar();

    // PRE:
    // POS: elimina al personaje liberando la memoria.
    virtual ~Aire();
};

#endif //TP2_AIRE_H
