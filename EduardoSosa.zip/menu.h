#ifndef TP2_MENU_H
#define TP2_MENU_H

#include <iostream>
#include "lista.h"
#include "accionesMenu.h"

const int SALIR = 6;

using namespace std;

class Menu
{
public:
    Menu();

    //Muestra las acciones disponibles.
    void mostrarMenu();

    //Llama a la función correspondiente según el caracter ingresado.
    //Los int válidos se pueden ver llamando a mostrarMenu().
    void ejecutarInstruccion(int instruccion, Lista &lista);

    //PRE:
    //POS:
    virtual ~Menu() = 0;
};
#endif //TP2_MENU_H
