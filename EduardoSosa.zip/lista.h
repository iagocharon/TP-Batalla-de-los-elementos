#ifndef TP2_LISTA_H
#define TP2_LISTA_H

#include "nodo.h"

class Lista
{
private:
    int cantidadElementos;
    Nodo* primero;
    Nodo* ultimo;

public:
    // PRE:
    // POS: crea una lista vacía.
    Lista();

    // PRE:
    // POS: añade un nodo a la lista en la ultima posición.
    void alta(Nodo* elemento);

    // PRE: (posicion empieza de 0)
    // POS: añade un nodo a la lista en la posición solicitada. (Si se encuentra fuera de rango lo agrega al final)
    void alta(int posicion, Nodo* elemento);

    // PRE:
    // POS: elimina el nodo en la ultima posición de la lista.
    void baja();

    // PRE:
    // POS: elimina el nodo de la posición solicitada. (Si se encuentra fuera de rango elimina el ultimo)
    void baja(int posicion);

    // PRE:
    // POS: devuelve un puntero al primer nodo de la lista (o nullptr si esta vacía).
    Nodo* consultarPrimero();

    // PRE:
    // POS: elimina la lista y con sus nodos.
    virtual ~Lista();
};

#endif //TP2_LISTA_H
