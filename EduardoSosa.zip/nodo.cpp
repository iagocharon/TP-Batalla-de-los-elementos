#include "nodo.h"

//CONSTRUCTOR
Nodo::Nodo()
{
    dato = nullptr;
    siguiente = nullptr;
}

void Nodo::cambiarSiguiente(Nodo* nuevoSiguiente)
{
    siguiente = nuevoSiguiente;
}

void Nodo::cambiarDato(Dato nuevoDato)
{
    delete dato;
    dato = nuevoDato;
}

// PRE:
// POS: devuelve el dato almacenado.
Dato Nodo::obtenerDato()
{
    return dato;
}

Nodo* Nodo::obtenerSiguiente()
{
    return siguiente;
}

Nodo::~Nodo()
{
    delete dato;
}
