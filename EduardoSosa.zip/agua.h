#ifndef TP2_AGUA_H
#define TP2_AGUA_H

#include "personaje.h"

using namespace std;

const int ALIMENTADOINICIAL = 0;
const string AGUA = "agua";
const string ALIMENTOAGUA = "plancton";
const int ALIMENTOMAX = 3;
const int RECUPERAAGUA = 10;

class Agua : public Personaje
{
private:
    int vecesAlimentado;

public:
    // PRE:
    // POS: crea un personaje de agua con nombre = nombre, escudo = escudo,
    //      vida = vida, energía aleatoria entre ENERGIAMIN y ENERGIAMAX, y vecesAlimentado = 0.
    Agua(string nombre, int escudo, int vida);

    // PRE:
    // POS: muestra toda la informacion del personaje.
    void mostrarInformacion();

    // PRE:
    // POS: alimenta al personaje y muestra el efecto provocado.
    void alimentar();

    // PRE:
    // POS: elimina al personaje liberando la memoria.
    virtual ~Agua();

private:
    //PRE:
    //POS: Devuelve la cantidad de energía que recupera el personaje.
    int recuperadoAgua(int energia);

};
#endif //TP2_AGUA_H
