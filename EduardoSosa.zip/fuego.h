#ifndef TP2_FUEGO_H
#define TP2_FUEGO_H

#include "personaje.h"

using namespace std;

const string FUEGO = "fuego";
const string ALIMENTOFUEGO = "madera";
const int RECUPERAFUEGO = 15;

class Fuego : public Personaje
{
public:
    // PRE:
    // POS: crea un personaje de fuego con nombre = nombre, escudo = escudo,
    //      vida = vida, energía aleatoria entre ENERGIAMIN y ENERGIAMAX.
    Fuego(string nombre, int escudo, int vida);

    // PRE:
    // POS: muestra toda la informacion del personaje.
    void mostrarInformacion();

    // PRE:
    // POS: alimenta al personaje y muestra el efecto provocado.
    void alimentar();

    // PRE:
    // POS: elimina al personaje liberando la memoria.
    virtual ~Fuego();

private:
    //PRE:
    //POS: Devuelve la cantidad de vida que recupera el personaje.
    int recuperadoFuego(int vida);

};
#endif //TP2_FUEGO_H
