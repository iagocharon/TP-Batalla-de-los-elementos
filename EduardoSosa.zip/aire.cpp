#include "aire.h"

//CONSTRUCTOR
Aire::Aire(string nombre, int escudo, int vida) : Personaje(nombre, escudo, vida) {}

void Aire::alimentar()
{
    cout << "\nEste Personaje no necesita alimentarse" << endl;
}

void Aire::mostrarInformacion()
{
    Personaje::mostrarInformacion();
    cout << "Elemento: " << AIRE << endl;
}

Aire::~Aire(){}