#ifndef TP2_NODO_H
#define TP2_NODO_H

#include "personaje.h"
#include "agua.h"
#include "fuego.h"
#include "tierra.h"
#include "aire.h"

using namespace std;

typedef Personaje* Dato;

class Nodo
{
private:
    Dato dato;
    Nodo* siguiente;

public:
    // PRE:
    // POS: crea un nodo con dato = 0 y siguiente = 0.
    Nodo();

    // PRE:
    // POS: cambia el dato actual por nuevoDato.
    void cambiarDato(Dato nuevoDato);

    // PRE:
    // POS: hace que siguiente apunte a nuevoSiguiente.
    void cambiarSiguiente(Nodo* nuevoSiguiente);

    // PRE:
    // POS: devuelve el dato almacenado.
    Dato obtenerDato();

    // PRE:
    // POS: devuelve un puntero al nodo al que siguiente apunte.
    Nodo* obtenerSiguiente();

    // PRE:
    // POS: elimina el nodo.
    ~Nodo();
};

#endif //TP2_NODO_H
