#include "agua.h"

//CONSTRUCTOR
Agua::Agua(string nombre, int escudo, int vida) : Personaje(nombre, escudo, vida)
{
    this->vecesAlimentado = ALIMENTADOINICIAL;
}


//PRE:
//POS: Devuelve la cantidad de energía que recupera el personaje.
int Agua::recuperadoAgua(int energia)
{
    if(energia + RECUPERAAGUA > ENERGIAMAX)
    {
        return RECUPERAAGUA - ((energia + RECUPERAAGUA) - ENERGIAMAX);
    }
    else
    {
        return RECUPERAAGUA;
    }
}


//FUNCIONES Y METODOS PRINCIPALES
void Agua::mostrarInformacion()
{
    Personaje::mostrarInformacion();
    cout << "Elemento: " << AGUA << endl;
    cout << "Veces alimentado: " << vecesAlimentado << endl;
}

void Agua::alimentar()
{
    int recuperado = 0;

    if(vecesAlimentado == ALIMENTOMAX)
      {
        cout << "\nYa no se puede alimentar." << endl;
      }else {
        recuperado = recuperadoAgua(energia);
        energia += recuperado;
        vecesAlimentado++;
        cout << "\nAlimentado con " << ALIMENTOAGUA << endl;
        cout << "Recupera " << recuperado << " puntos de energía" << endl;
    }
}

Agua::~Agua(){}