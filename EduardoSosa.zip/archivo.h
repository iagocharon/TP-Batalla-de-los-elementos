#ifndef TP2_ARCHIVO_H
#define TP2_ARCHIVO_H

#include "lista.h"
#include <string>
#include <iostream>
#include <fstream>

const string ARCHIVO = "personajes.csv";

using namespace std;

class Archivo{
public:

    //PRE:
    //POS:
    Archivo();

    //PRE:
    //POS: Devuelve una lista con los datos de ARCHIVO, si no lo encuentra o no lo puede leer devuelve una
    // lista vacía.
    Lista cargarPersonajes();

    //PRE:
    //POS:
    virtual ~Archivo() = 0;
};


#endif //TP2_ARCHIVO_H
