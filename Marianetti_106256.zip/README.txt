Linea para compilar: g++ *.cpp -o tp2 (+flags)
