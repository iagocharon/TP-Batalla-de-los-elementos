#include "Lista.hpp"

Lista::Lista() {
    this->primero = NULL;
    this->largo = 0;
}


bool Lista::lista_vacia() {
    if (primero == NULL) {
        return true;
    }
    else {
        return false;
    }
}

void Lista::insertar(Personaje* personaje, unsigned posicion) {
    Nodo_lista* nuevo = new Nodo_lista(personaje);
    if (posicion == 0){
        nuevo->set_siguiente(this->primero);
        this->primero = nuevo;
    }
    else {
        Nodo_lista* anterior = get_nodo(posicion - 1);
        nuevo->set_siguiente(anterior->get_siguiente());
        anterior->set_siguiente(nuevo);
    }
    this->largo++;
}

void Lista::insertar(Personaje* personaje) {
    int posicion = 0;
    Personaje* auxiliar;
    if (personaje->get_elemento() == AGUA) {
        auxiliar = new Personaje_agua(personaje->get_nombre(), personaje->get_elemento(), personaje->get_escudo(), personaje->get_vida());
    }
    else if (personaje->get_elemento() == AIRE) {
        auxiliar = new Personaje_aire(personaje->get_nombre(), personaje->get_elemento(), personaje->get_escudo(), personaje->get_vida());
    }
    else if (personaje->get_elemento() == TIERRA) {
        auxiliar = new Personaje_tierra(personaje->get_nombre(), personaje->get_elemento(), personaje->get_escudo(), personaje->get_vida());
    }
    else if (personaje->get_elemento() == FUEGO) {
        auxiliar = new Personaje_fuego(personaje->get_nombre(), personaje->get_elemento(), personaje->get_escudo(), personaje->get_vida());
    }
    else {
        return;
    }
    if (this->primero != NULL) {
        Nodo_lista* nodo_auxiliar = this->primero;
        if (this->largo > 0) {
            while ((personaje->get_nombre() > nodo_auxiliar->get_personaje()->get_nombre()) && (nodo_auxiliar->get_siguiente() != NULL)) {
                nodo_auxiliar = nodo_auxiliar->get_siguiente();
                posicion++;
            }
        }
        else {
            posicion++;
        }
    }
    this->insertar(auxiliar, posicion);
    delete auxiliar;
    
}

Personaje* Lista::get_personaje(unsigned posicion) {
    Nodo_lista* auxiliar = get_nodo(posicion);
    return auxiliar->get_personaje();
}

void Lista::eliminar_personaje(unsigned posicion) {
    Nodo_lista* borrar = this->primero;
    if (posicion == 0){
        primero = borrar->get_siguiente();
    }
    else {
        Nodo_lista* anterior = get_nodo(posicion - 1);
        borrar = anterior->get_siguiente();
        anterior->set_siguiente(borrar->get_siguiente());
    }
    delete borrar;
    this->largo--;
}

void Lista::eliminar_personaje(string nombre) {
    int posicion = 0;
    Nodo_lista* auxiliar = this->primero;
    while ((nombre > auxiliar->get_personaje()->get_nombre()) && (auxiliar->get_siguiente() != NULL)) {
        auxiliar = auxiliar->get_siguiente();
        posicion++;
    }
    if (auxiliar->get_personaje()->get_nombre() != nombre) {
        cout << "\tNo se encontro al personaje buscado." << endl;
    }
    else {
        this->eliminar_personaje(posicion);
        cout << "\tEl personaje se elimino correctamente." << endl;
    }
}

void Lista::mostrar() {
    for (int i = 0; i < this->largo; i++) {
        cout << "\t" << this->get_personaje(i)->get_nombre() << endl;
    }
}

Personaje* Lista::buscar(string nombre) {
    int posicion = 0;
    Nodo_lista* auxiliar = this->primero;
    while ((nombre > auxiliar->get_personaje()->get_nombre()) && (posicion < this->largo)) {
        posicion++;
        auxiliar = auxiliar->get_siguiente();
    }
    if (nombre != auxiliar->get_personaje()->get_nombre()) {
        return NULL;
    }
    else {
        return auxiliar->get_personaje();
    }
}

unsigned Lista::get_largo() {
    return this->largo;
}

Nodo_lista* Lista::get_nodo(unsigned posicion) {
    Nodo_lista* auxiliar = this->primero;
    unsigned i = 0;
    while (i < posicion){
        auxiliar = auxiliar->get_siguiente();
        i++;
    }
    return auxiliar;
}

Lista::~Lista() {
    while (!(this->lista_vacia())) {
        this->eliminar_personaje(0);
    }
}
