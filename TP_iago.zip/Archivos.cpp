#include "Archivos.hpp"

Archivos::Archivos() {

}

void Archivos::leer_personajes(Lista* lista_personajes) {
    ifstream archivo(NOMBRE_ARCHIVO);
    if (!archivo.fail()) {
        while (!archivo.eof()) {
            string linea;
            getline(archivo, linea);
            stringstream stream(linea);
            if (stream.good()){
                string substring;
                getline(stream, substring, ',');
                string elemento = substring;
                getline(stream, substring, ',');
                string nombre = substring;
                nombre = this->convertir_palabra(nombre);
                getline(stream, substring, ',');
                int escudo = stoi(substring);
                getline(stream, substring);
                int vida = stoi(substring);
                
                Personaje* nuevo = new Personaje(nombre, elemento, escudo, vida);
                lista_personajes->insertar(nuevo);
                delete nuevo;
            }
        }
        archivo.close();
    }
    else {
        cout << "Error al abrir el archivo." << endl;
    }
}

string Archivos::convertir_palabra(string palabra) {
    transform(palabra.begin(), palabra.end(), palabra.begin(), ::tolower);
    palabra[0] = toupper(palabra[0]);
    return palabra;
}

Archivos::~Archivos() {
    
}
