#ifndef Lista_hpp
#define Lista_hpp

#include <iostream>
#include "Nodo_lista.hpp"
#include "Personaje.hpp"

using namespace std;

class Lista{
private:
    Nodo_lista* primero;
    int largo;

public:
    Lista();

    bool lista_vacia();
    void insertar(Personaje* personaje, unsigned pos);
    void insertar(Personaje* personaje);
    void eliminar_personaje(unsigned pos);
    void eliminar_personaje(string nombre);
    void mostrar();
    Personaje* buscar(string nombre);

    Nodo_lista* get_nodo(unsigned pos);
    Personaje* get_personaje(unsigned pos);
    unsigned get_largo();

    ~Lista();
};


#endif /* Lista_hpp */
