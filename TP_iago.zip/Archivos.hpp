#ifndef Archivos_hpp
#define Archivos_hpp

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "Personaje.hpp"
#include "Lista.hpp"
#include "Menu.hpp"

#define NOMBRE_ARCHIVO "personajes.csv"

using namespace std;

class Archivos {
public:
    Archivos();
    void leer_personajes(Lista* lista_personajes);
    string convertir_palabra(string palabra);
    ~Archivos();
};



#endif /* Archivos_hpp */
