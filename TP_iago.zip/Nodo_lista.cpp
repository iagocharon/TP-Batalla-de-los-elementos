#include "Nodo_lista.hpp"

Nodo_lista::Nodo_lista(Personaje* personaje) {
    this->personaje = personaje;
    this->siguiente = NULL;
}

Personaje* Nodo_lista::get_personaje() {
    return this->personaje;
}

Nodo_lista* Nodo_lista::get_siguiente() {
    return this->siguiente;
}

void Nodo_lista::set_personaje(Personaje* personaje) {
    this->personaje = personaje;
}

void Nodo_lista::set_siguiente(Nodo_lista* siguiente) {
    this->siguiente = siguiente;
}

Nodo_lista::~Nodo_lista() {
     
}
