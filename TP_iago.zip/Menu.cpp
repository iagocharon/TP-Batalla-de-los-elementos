#include "Menu.hpp"

Menu::Menu() {
    
}

void Menu::mostrar_menu() {
    this->enmarcar("LA BATALLA DE LOS ELEMENTOS");
    cout << "\t1. Agregar un nuevo personaje." << endl;
    cout << "\t2. Eliminar un personaje." << endl;
    cout << "\t3. Mostrar todos los nombres de los personajes." << endl;
    cout << "\t4. Buscar por nombre los detalles de un personaje en particular." << endl;
    cout << "\t5. Alimentar un personaje." << endl;
    cout << "\t6. Salir." << endl;
    cout << endl << "\tELECCION: ";
    cin >> this->eleccion;
}

void Menu::hacer_eleccion(Lista* personajes) {
    this->mostrar_menu();
    this->limpiar_pantalla();
    while (this->eleccion != 6) {
        switch (this->eleccion) {
            case 1:
                this->enmarcar("AGREGAR NUEVO PERSONAJE");
                this->agregar_personaje(personajes);
                break;
            case 2:
                this->enmarcar("ELIMINAR UN PERSONAJE");
                this->eliminar_personaje(personajes);
                break;
            case 3:
                this->enmarcar("MOSTRANDO TODOS LOS PERSONAJES");
                this->mostrar_personajes(personajes);
                break;
            case 4:
                this->enmarcar("BUSCAR PERSONAJE");
                this->buscar_personaje(personajes);
                break;
            case 5:
                this->enmarcar("ALIMENTAR A UN PERSONAJE");
                this->alimentar(personajes);
                break;
        }
        this->pausa();
//        this->limpiar_pantalla(); //CON ESTO, BORRA EL NOMBRE DEL PERSONAJE CUANDO LO CREAS.
        this->mostrar_menu();
    }
    this->limpiar_pantalla();
    this->enmarcar("FIN DEL PROGRAMA");
}


void Menu::agregar_personaje(Lista* personajes) {
    srand((unsigned) time(0));
    string nombre;
    cout << "\tIngrese el nombre del personaje a crear: ";
    cin >> nombre;
    nombre = this->convertir_palabra(nombre);
    int elemento_numero = (rand() % 4) + 1;// 1. aire - 2. fuego - 3. tierra - 4. agua.
    string elemento;
    switch (elemento_numero) {
        case 1:
            elemento = AIRE;
            break;
        case 2:
            elemento = FUEGO;
            break;
        case 3:
            elemento = TIERRA;
            break;
        case 4:
            elemento = AGUA;
            break;
        default:
            break;
    }
    int escudo = (rand() % (MAXIMO_ESCUDO - MINIMO_ESCUDO + 1)) + MINIMO_ESCUDO;
    int vida = (rand() % (MAXIMO_VIDA - MINIMO_VIDA + 1)) + MINIMO_VIDA;
    Personaje* nuevo = new Personaje(nombre, elemento, escudo, vida);
    personajes->insertar(nuevo);
//    delete nuevo;
}

void Menu::eliminar_personaje(Lista *personajes) {
    this->mostrar_personajes(personajes);
    cout << endl;
    string nombre_eliminar;
    cout << "\tIngrese el nombre del personaje que desea eliminar: ";
    cin >> nombre_eliminar;
    nombre_eliminar = this->convertir_palabra(nombre_eliminar);
    personajes->eliminar_personaje(nombre_eliminar);
}

void Menu::mostrar_personajes(Lista* personajes) {
    personajes->mostrar();
}

void Menu::buscar_personaje(Lista *personajes) {
    this->mostrar_personajes(personajes);
    cout << endl;
    string nombre;
    cout << "\tIngrese el nombre del personaje a buscar: ";
    cin >> nombre;
    nombre = this->convertir_palabra(nombre);
    cout << endl;
    Personaje* buscado = personajes->buscar(nombre);
    buscado->mostrar();
}

void Menu::alimentar(Lista *personajes) {
    this->mostrar_personajes(personajes);
    cout << endl;
    string nombre;
    cout << "\tIngrese el nombre del personaje a alimentar: ";
    cin >> nombre;
    nombre = this->convertir_palabra(nombre);
    cout << endl;
    Personaje* alimentar = personajes->buscar(nombre);
    alimentar->alimentar();
}




string Menu::convertir_palabra(string palabra) {
    transform(palabra.begin(), palabra.end(), palabra.begin(), ::tolower);
    palabra[0] = toupper(palabra[0]);
    return palabra;
}

void Menu::limpiar_pantalla() {
    system(CLEAR);
}

void Menu::enmarcar(string texto) {
    int margen;
    int tamanio = int(texto.length());
    margen = ((ANCHO_PANTALLA / 2) - (tamanio / 2));
    for ( int i = 0; i < margen; i++) cout << " ";
    cout << "┌";
    for ( int i = 0; i < tamanio; i++) cout << "─";
    cout << "┐" << endl;
    for ( int i = 0; i < margen; i++) cout << " ";
    cout << "│" << texto << "│" << endl;
    for ( int i = 0; i < margen; i++) cout << " ";
    cout << "└";
    for ( int i = 0; i < tamanio; i++) cout << "─";
    cout << "┘" << endl;
}

void Menu::pausa() {
    cout << endl << endl << "<Enter>";
    cin.get();
    cin.get();
}

void Menu::fin_del_programa() {
    this->limpiar_pantalla();
    this->enmarcar("FIN DEL PROGRAMA");
    this->pausa();
}

Menu::~Menu() {
    
}
