#include "Personaje.hpp"

Personaje::Personaje() {
    this->nombre = "";
    this->elemento = "";
    this->escudo = 0;
    this->vida = 0;
    this->energia = 0;
}

Personaje::Personaje(string nombre, string elemento, int escudo, int vida) {
    this->nombre = nombre;
    this->elemento = elemento;
    this->escudo = escudo;
    this->vida = vida;
    srand((unsigned) time(0));
    int energia = rand() % (MAXIMO_ENERGIA + 1);
    this->energia = energia;
}

string Personaje::get_nombre() {
    return this->nombre;
}

string Personaje::get_elemento() {
    return this->elemento;
}

int Personaje::get_escudo() {
    return this->escudo;
}

int Personaje::get_vida() {
    return this->vida;
}

int Personaje::get_energia() {
    return this->energia;
}

void Personaje::set_nombre(string nombre) {
    this->nombre = nombre;
}

void Personaje::set_elemento(string elemento) {
    this->elemento = elemento;
}

void Personaje::set_escudo(int escudo) {
    this->escudo = escudo;
}

void Personaje::set_vida(int vida) {
    this->vida = vida;
}

void Personaje::set_energia(int energia) {
    this->energia = energia;
}

void Personaje::alimentar() {
    
}

void Personaje::mostrar() {
    cout << "\tNOMBRE: " << this->nombre << endl;
    cout << "\tELEMENTO: " << this->elemento << endl;
    cout << "\tESCUDO: " << this->escudo << endl;
    cout << "\tVIDA: " << this->vida << endl;
    cout << "\tENERGIA: " << this->energia << endl;
}

Personaje::~Personaje() {
    
}


Personaje_agua::Personaje_agua(string nombre, string elemento, int escudo, int vida) : Personaje(nombre, elemento, escudo, vida) {
    this->veces_alimentado = 0;
}

void Personaje_agua::cambiar_dia() {
    this->veces_alimentado = 0;
}

void Personaje_agua::alimentar() {
    if ((this->veces_alimentado < 3) && (this->get_energia() < MAXIMO_ENERGIA)) {
        this->set_energia(this->get_energia() + RECUPERACION_AGUA);
        if (this->get_energia() > MAXIMO_ENERGIA) {
            this->set_energia(MAXIMO_ENERGIA);
        }
        this->veces_alimentado++;
        cout << "\tEl personaje " << this->get_nombre() << " ha sido alimentado correctamente y tiene " << this->get_energia() << " puntos de energia" << endl;
    }
    else if (this->veces_alimentado < 3) {
        cout << "\tYa se llego al limite de energia (" << MAXIMO_ENERGIA << ")." << endl;
    }
    else {
        cout << "\tEste personaje ya ha sido alimentado lo suficiente por un dia." << endl;
    }
}

Personaje_agua::~Personaje_agua() {
    
}


Personaje_tierra::Personaje_tierra(string nombre, string elemento, int escudo, int vida) : Personaje(nombre, elemento, escudo, vida) {
    
}

void Personaje_tierra::alimentar() {
    if (this->get_energia() < MAXIMO_ENERGIA) {
        this->set_energia(this->get_energia() + RECUPERACION_TIERRA);
        if (this->get_energia() > MAXIMO_ENERGIA) {
            this->set_energia(MAXIMO_ENERGIA);
        }
        cout << "\tEl personaje " << this->get_nombre() << " ha sido alimentado correctamente y tiene " << this->get_energia() << " puntos de energia" << endl;
    }
    else {
        cout << "\tYa se llego al limite de energia (" << MAXIMO_ENERGIA << ")." << endl;
    }
}

Personaje_tierra::~Personaje_tierra() {
    
}

Personaje_fuego::Personaje_fuego(string nombre, string elemento, int escudo, int vida) : Personaje(nombre, elemento, escudo, vida) {
    
}

void Personaje_fuego::alimentar() {
    if (this->get_energia() < MAXIMO_ENERGIA) {
        this->set_energia(this->get_energia() + RECUPERACION_FUEGO);
        if (this->get_energia() > MAXIMO_ENERGIA) {
            this->set_energia(MAXIMO_ENERGIA);
        }
        cout << "\tEl personaje " << this->get_nombre() << " ha sido alimentado correctamente y tiene " << this->get_energia() << " puntos de energia" << endl;
    }
    else {
        cout << "\tYa se llego al limite de energia (" << MAXIMO_ENERGIA << ")." << endl;
    }
}

Personaje_fuego::~Personaje_fuego() {
    
}

Personaje_aire::Personaje_aire(string nombre, string elemento, int escudo, int vida) : Personaje(nombre, elemento, escudo, vida) {
    
}

void Personaje_aire::alimentar() {
    cout << "\tLos personajes de elemento aire no necesitan ser alimentados." << endl;
}

Personaje_aire::~Personaje_aire() {
    
}
