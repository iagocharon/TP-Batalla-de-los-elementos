#include <iostream>
#include "Personaje.hpp"
#include "Nodo_lista.hpp"
#include "Lista.hpp"
#include "Archivos.hpp"
#include "Menu.hpp"

using namespace std;

int main() {
    
    Archivos* archivo = new Archivos();
    Lista* personajes = new Lista();
    Menu* menu = new Menu();
    
    archivo->leer_personajes(personajes);
    menu->hacer_eleccion(personajes);
    
    menu->fin_del_programa();
    delete archivo;
    delete personajes;
    delete menu;
    
    
    
    return 0;
}
