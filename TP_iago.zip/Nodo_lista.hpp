#ifndef Nodo_lista_hpp
#define Nodo_lista_hpp

#include <iostream>
#include "Personaje.hpp"

using namespace std;

class Nodo_lista {
private:
    Personaje* personaje;
    Nodo_lista* siguiente;
    
public:
    Nodo_lista(Personaje* personaje);
    
    Personaje* get_personaje();
    Nodo_lista* get_siguiente();
    
    void set_personaje(Personaje* personaje);
    void set_siguiente(Nodo_lista* siguiente);
    
    ~Nodo_lista();
};



#endif /* Nodo_lista_hpp */
