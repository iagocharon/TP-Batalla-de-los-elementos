#ifndef Menu_hpp
#define Menu_hpp

#ifdef _WIN32
#define CLEAR "cls"
#else
#define CLEAR "clear"
#endif

#include <iostream>
#include <ctime>
#include "Personaje.hpp"
#include "Lista.hpp"


#define ANCHO_PANTALLA 70

using namespace std;

class Menu {
private:
    int eleccion;// entre 1 y 6

public:
    Menu();
    void mostrar_menu();
    void hacer_eleccion(Lista* personajes);
    
    void agregar_personaje(Lista* personajes);
    void eliminar_personaje(Lista* personajes);
    void mostrar_personajes(Lista* personajes);
    void buscar_personaje(Lista* personajes);
    void alimentar(Lista* personajes);
    
    string convertir_palabra(string palabra);
    
    void limpiar_pantalla();
    void enmarcar(string texto);
    void pausa();
    void fin_del_programa();
    
    ~Menu();
};

#endif /* Menu_hpp */
