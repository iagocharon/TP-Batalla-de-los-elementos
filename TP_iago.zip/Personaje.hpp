#ifndef Personaje_hpp
#define Personaje_hpp

#include <iostream>
#include <ctime>

#define AGUA "Agua"
#define AIRE "Aire"
#define TIERRA "Tierra"
#define FUEGO "Fuego"
#define MINIMO_ESCUDO 0
#define MAXIMO_ESCUDO 2
#define MINIMO_VIDA 10
#define MAXIMO_VIDA 100
#define MINIMO_ENERGIA 0
#define MAXIMO_ENERGIA 20
#define RECUPERACION_AGUA 10
#define LIMITE_DIARIO_AGUA 3
#define RECUPERACION_TIERRA 8
#define RECUPERACION_FUEGO 15


using namespace std;

class Personaje {
private:
    string nombre;
    string elemento;
    int escudo; // 0, 1 o 2
    int vida; // entre 10 y 100
    int energia; // entre 0 y 20
    
public:
    Personaje();
    Personaje(string nombre, string elemento, int escudo, int vida);
    
    virtual string get_nombre();
    virtual string get_elemento();
    virtual int get_escudo();
    virtual int get_vida();
    virtual int get_energia();
    
    virtual void set_nombre(string nombre);
    virtual void set_elemento(string elemento);
    virtual void set_escudo(int escudo);
    virtual void set_vida(int vida);
    virtual void set_energia(int energia);
    
    virtual void alimentar();
    virtual void mostrar();
    
    virtual ~Personaje();
};


class Personaje_agua : public Personaje {
private:
    int veces_alimentado;
    
public:
    Personaje_agua(string nombre, string elemento, int escudo, int vida);
    void cambiar_dia();
    virtual void alimentar();
    virtual ~Personaje_agua();
};


class Personaje_tierra : public Personaje {
public:
    Personaje_tierra(string nombre, string elemento, int escudo, int vida);
    virtual void alimentar();
    ~Personaje_tierra();
};


class Personaje_fuego : public Personaje {
public:
    Personaje_fuego(string nombre, string elemento, int escudo, int vida);
    virtual void alimentar();
    virtual~Personaje_fuego();
};


class Personaje_aire : public Personaje {
public:
    Personaje_aire(string nombre, string elemento, int escudo, int vida);
    virtual void alimentar();
    virtual ~Personaje_aire();
};



#endif /* Personaje_hpp */
